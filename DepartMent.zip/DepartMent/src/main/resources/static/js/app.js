const API_URL = '/departments';
let isEditing = false;
let currentEditId = null;

// DOM Elements
const form = document.getElementById('deptForm');
const formTitle = document.getElementById('formTitle');
const submitBtn = document.getElementById('submitBtn');
const cancelBtn = document.getElementById('cancelBtn');
const deptList = document.getElementById('deptList');
const nameInput = document.getElementById('departmentName');
const addressInput = document.getElementById('departmentAddress');
const codeInput = document.getElementById('departmentCode');

// Event Listeners
document.addEventListener('DOMContentLoaded', fetchDepartments);
form.addEventListener('submit', handleFormSubmit);
cancelBtn.addEventListener('click', resetForm);

// Fetch all departments
async function fetchDepartments() {
    try {
        const response = await fetch(API_URL);
        const departments = await response.json();
        renderDepartments(departments);
    } catch (error) {
        showToast('Error fetching departments', 'error');
        console.error('Error:', error);
    }
}

// Render list
function renderDepartments(departments) {
    deptList.innerHTML = '';
    if (departments.length === 0) {
        deptList.innerHTML = '<div style="text-align:center; color: var(--text-muted); padding: 2rem;">No departments found. Add one!</div>';
        return;
    }

    departments.forEach(dept => {
        const item = document.createElement('div');
        item.className = 'department-item';
        item.innerHTML = `
            <div class="dept-info">
                <h3>${dept.departmentName}</h3>
                <p>📍 ${dept.departmentAddress}</p>
                <p>🏷️ ${dept.departmentCode}</p>
            </div>
            <div class="dept-actions">
                <button class="icon-btn edit-btn" onclick="startEdit(${dept.departmentId}, '${dept.departmentName}', '${dept.departmentAddress}', '${dept.departmentCode}')">
                    ✏️
                </button>
                <button class="icon-btn delete-btn" onclick="deleteDepartment(${dept.departmentId})">
                    🗑️
                </button>
            </div>
        `;
        deptList.appendChild(item);
    });
}

// Handle Form Submit (Create or Update)
async function handleFormSubmit(e) {
    e.preventDefault();

    const data = {
        departmentName: nameInput.value,
        departmentAddress: addressInput.value,
        departmentCode: codeInput.value
    };

    try {
        if (isEditing) {
            await fetch(`${API_URL}/${currentEditId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
            showToast('Department updated successfully!', 'success');
        } else {
            await fetch(API_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
            showToast('Department created successfully!', 'success');
        }
        resetForm();
        fetchDepartments();
    } catch (error) {
        showToast('Operation failed', 'error');
        console.error('Error:', error);
    }
}

// Delete Department
window.deleteDepartment = async function (id) {
    if (!confirm('Are you sure you want to delete this department?')) return;

    try {
        await fetch(`${API_URL}/${id}`, {
            method: 'DELETE'
        });
        showToast('Department deleted successfully', 'success');
        fetchDepartments();
    } catch (error) {
        showToast('Error deleting department', 'error');
        console.error('Error:', error);
    }
};

// Start Edit Mode
window.startEdit = function (id, name, address, code) {
    isEditing = true;
    currentEditId = id;

    nameInput.value = name;
    addressInput.value = address;
    codeInput.value = code;

    formTitle.innerText = 'Edit Department';
    submitBtn.innerText = 'Update Department';
    cancelBtn.style.display = 'block';

    // Scroll to form
    document.querySelector('.input-group').scrollIntoView({ behavior: 'smooth' });
};

// Reset Form
function resetForm() {
    isEditing = false;
    currentEditId = null;
    form.reset();

    formTitle.innerText = 'Add New Department';
    submitBtn.innerText = 'Create Department';
    cancelBtn.style.display = 'none';
}

// Toast Notification
function showToast(message, type) {
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.style.borderLeft = `4px solid ${type === 'error' ? 'var(--danger-color)' : 'var(--success-color)'}`;
    toast.innerText = message;

    document.body.appendChild(toast);

    setTimeout(() => toast.classList.add('show'), 100);

    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}
